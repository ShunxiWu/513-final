import serial
import csv
from datetime import datetime
import os

# 打开串口
ser = serial.Serial('COM20', 115200)  # 替换'COMx'为您的串行端口号

# 创建 CSV 文件并写入标题行
file_counter = 0  # 文件计数器
data_folder = 'C:/Users/Shun-Xi Wu/Desktop/data'
os.makedirs(data_folder, exist_ok=True)

def get_file_path(counter):
    return os.path.join(data_folder, f"test{counter}.csv")

def create_csv(file_path):
    with open(file_path, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Time", "Duration","IMU1 AccX", "IMU1 AccY", "IMU1 AccZ", "IMU1 GyroX", "IMU1 GyroY", "IMU1 GyroZ",
                         "IMU2 AccX", "IMU2 AccY", "IMU2 AccZ", "IMU2 GyroX", "IMU2 GyroY", "IMU2 GyroZ",
                         "IMU3 AccX", "IMU3 AccY", "IMU3 AccZ", "IMU3 GyroX", "IMU3 GyroY", "IMU3 GyroZ"])

while True:
    try:
        # 检查文件是否存在，如果不存在则创建
        file_path = get_file_path(file_counter)
        if not os.path.exists(file_path):
            create_csv(file_path)

        # 读取串口数据并将其写入 CSV 文件
        with open(file_path, 'a', newline='') as file:
            writer = csv.writer(file)
            line = ser.readline().decode().strip()
            data = line.split(",")
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            writer.writerow([timestamp] + data)
    except Exception as e:
        print("Error:", e)
        break

# 关闭串口连接
ser.close()
